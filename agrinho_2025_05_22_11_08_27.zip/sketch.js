let plant;
let seedPlanted = false;
let growthStage = 0;

function setup() {
  createCanvas(600, 400);
  plant = new Plant(width / 2, height - 50); // Posição inicial da planta
}

function draw() {
  background(200, 230, 255); // Céu azul claro
  
  drawSun(); // Sol
  drawClouds(); // Nuvens
  
  if (seedPlanted) {
    plant.grow(); // Crescer a planta
  }
  
  plant.display(); // Mostrar a planta
  
}

function mousePressed() {
  seedPlanted = true; // Quando clica, planta a semente
}

function drawSun() {
  fill(255, 204, 0);
  noStroke();
  ellipse(100, 100, 100, 100); // Desenho do sol
}

function drawClouds() {
  fill(255, 255, 255, 150); // Cor das nuvens
  noStroke();
  ellipse(150, 50, 120, 60); // Nuvem 1
  ellipse(250, 70, 130, 70); // Nuvem 2
  ellipse(450, 40, 110, 50); // Nuvem 3
}

class Plant {
  constructor(x, y) {
    this.x = x;
    this.y = y;
    this.height = 0;
    this.leafSize = 20;
  }
  
  grow() {
    if (this.height < 150) {
      this.height += 1; // Cresce 1px por vez
    }
    
    if (this.height > 100) {
      this.leafSize += 0.1; // As folhas crescem mais
    }
  }
  
  display() {
    // Desenha o caule
    fill(34, 139, 34);
    rect(this.x - 5, this.y - this.height, 10, this.height);
    
    // Desenha as folhas
    fill(34, 139, 34);
    ellipse(this.x - 20, this.y - this.height + 30, this.leafSize, this.leafSize); // Folha esquerda
    ellipse(this.x + 20, this.y - this.height + 30, this.leafSize, this.leafSize); // Folha direita
    
    // Desenha a flor no topo (após atingir uma certa altura)
    if (this.height > 120) {
      fill(255, 99, 71);
      ellipse(this.x, this.y - this.height, 30, 30);
    }
  }
}
